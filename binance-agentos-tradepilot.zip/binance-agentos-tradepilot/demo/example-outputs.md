# Example Outputs (from real sessions)

## Example 1 — Full Analysis

**User:**
Analyze BTCUSDT with TradePilot. Full report.

**TradePilot:**
📊 **TradePilot Analysis — BTCUSDT**

**Price**: $112,450  |  24h: +1.87%  
**Trend**: Mildly Bullish (SMA20 above SMA50, price holding above both)  
**Volatility**: Medium  
**Risk Score**: 5/10

**Key Levels**
- Support: $109,800 – $110,200
- Resistance: $114,200 – $115,000

**Verdict**: Healthy short-term uptrend with moderate risk. Good environment for long setups on pullbacks.  
**Suggested Action**: Wait for a dip to $110.5k–$111k zone or breakout above $114.5k with volume.

---

## Example 2 — Trade Idea

**User:**
Give me a long idea on BTC with 1% risk.

**TradePilot:**
⚡ **TradePilot Idea — BTCUSDT**

**Bias**: Long  
**Entry Zone**: $110,800 – $111,200  
**Stop Loss**: $109,150  (≈1.7% from mid entry)  
**Take Profit**:
  - TP1: $113,800 (RR ≈ 1:1.8)
  - TP2: $116,200 (RR ≈ 1:3.2)

**Position Size**: Calculated so full stop-loss = 1% of current Agentic wallet  
(Example with $5,000 wallet → risk $50 → size ≈ 0.029 BTC)

**Reasoning**:
- Price holding above rising SMA20/SMA50
- Higher lows structure intact
- Funding neutral, no extreme leverage

**Confirmation required** before any order is placed.
