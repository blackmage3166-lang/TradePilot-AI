# TradePilot Risk Rules (Hard Constraints)

These rules are non-negotiable. Override only if the user explicitly accepts higher risk in the same conversation.

1. **Max risk per trade**: 1% of current Agentic sub-account equity (default). User can lower it, never raise without confirmation.
2. **No naked market orders** without stop-loss defined.
3. **Leverage limit**: Never suggest > 5x unless user has previously stated higher tolerance.
4. **Volatility filter**: If 24h range or ATR is extremely elevated, reduce size by 50% or skip.
5. **Portfolio heat**: Never risk more than 5% of total equity across all open positions.
6. **Confirmation gate**: Every live order requires explicit user approval in the current chat.
7. **Dry-run preferred**: Start every session in analysis / paper mode.
8. **No external transfers**: Agent cannot and must not attempt withdrawals.

If any rule would be broken, refuse the action and explain clearly.
