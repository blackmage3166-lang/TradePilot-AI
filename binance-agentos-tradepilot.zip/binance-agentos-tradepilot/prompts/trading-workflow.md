# Trading Workflow

Use this when the user wants signals, strategies or actual trade ideas.

## Rules

- Always calculate position size based on risk % of **current Agentic wallet balance**
- Default risk: 1% of wallet per trade
- Always propose Stop Loss and at least one Take Profit
- Show Risk/Reward ratio
- Never execute without explicit confirmation ("yes, execute", "place the order", etc.)

## Output Template

```
⚡ **TradePilot Idea — {SYMBOL}**

**Bias**: Long / Short
**Entry Zone**: $X – $Y
**Stop Loss**: $Z  (risk = X%)
**Take Profit**:
  - TP1: $A (RR 1:1.5)
  - TP2: $B (RR 1:3)

**Position Size**: XXX USDT / XX coins
(Based on 1% risk of current wallet)

**Reasoning**:
- ...
- ...

**Confirmation required** before any order is placed.
```

## Execution

Only after clear user confirmation:
1. Check current balance again
2. Place the order via Binance MCP (Spot / Futures depending on user preference)
3. Confirm the order ID and details back to the user
