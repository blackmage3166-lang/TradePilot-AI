# Analysis Workflow (Data & Analysis)

Use this when the user asks for market analysis, trend, volatility or portfolio insights.

## Required Steps

1. **Fetch live data** via Binance MCP:
   - Current price / ticker
   - 24h change, volume
   - Recent klines (1h or 4h preferred)

2. **Technical Snapshot**
   - SMA20 / SMA50 (or closest available)
   - Trend direction
   - Distance from key MAs
   - Volatility (ATR or simple high-low range)

3. **Risk Summary**
   - Current market regime (trending / ranging / high vol)
   - Suggested max risk per trade
   - Any red flags (funding rate extreme, low liquidity, etc.)

4. **Output Format**

```
📊 **TradePilot Analysis — {SYMBOL}**

**Price**: $XX,XXX  |  24h: +X.XX%
**Trend**: Bullish / Bearish / Ranging (SMA20 vs SMA50)
**Volatility**: Low / Medium / High
**Risk Score**: X/10

**Key Levels**
- Support: ...
- Resistance: ...

**Verdict**: ...
**Suggested Action**: ...
```
