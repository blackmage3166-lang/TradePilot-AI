#!/usr/bin/env python3
"""
TradePilot AI — Optional local helper
=====================================
This is a lightweight helper for local testing and demos.
The real power comes from using the official Binance MCP Server
with any MCP-compatible client (Claude, ChatGPT, Cursor, etc.).

You do NOT need this Python file to use TradePilot.
Just load the system prompt from prompts/tradepilot-system.md
"""

import os
from typing import Optional

# Placeholder — in a full version this would call the MCP tools
# or the official Binance REST API for offline demos.

def print_banner():
    print("""
╔══════════════════════════════════════════════════╗
║           TradePilot AI  —  Agent OS             ║
║     Binance Agent OS Mini Hackathon (Track A)    ║
╚══════════════════════════════════════════════════╝
    """)

def show_usage():
    print("""
How to use TradePilot (recommended way):

1. Connect the official Binance MCP:
   claude mcp add binance-mcp-server --transport http https://agent.binance.com/mcp/agentic

2. Authenticate and grant permissions

3. Copy the content of prompts/tradepilot-system.md
   into your system prompt / Claude Skill / Custom GPT

4. Start chatting:
   "Analyze BTCUSDT with TradePilot"
   "Give me a long idea with 1% risk"
   "Scan top movers and suggest 3 setups"

That's it. No API keys needed — Agent OS handles auth.
    """)

if __name__ == "__main__":
    print_banner()
    show_usage()
