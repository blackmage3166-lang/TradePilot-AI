# Architecture — TradePilot AI

## High-level Design

```
User (Claude / ChatGPT / Cursor / etc.)
          │
          ▼
   TradePilot System Prompt + Skills
          │
          ▼
   Binance Official MCP Server
   (https://agent.binance.com/mcp/agentic)
          │
          ▼
   Binance Agentic Sub-Account
   (isolated, no withdrawal rights)
```

## Why this design wins for the hackathon

- Uses the **official** Binance Agent OS / MCP (not a third-party wrapper)
- Covers all four workflow categories shown in the official images
- Safety-first (sub-account isolation + risk rules)
- Extremely easy to demo (just connect MCP + load the prompt)
- Extensible (can add more skills later)

## Components

1. **System Prompt** (`prompts/tradepilot-system.md`) — the brain
2. **Workflow modules** — specialized instructions for analysis vs trading
3. **Risk engine** — hard constraints that the LLM must follow
4. **Optional Python helper** — for local testing / advanced users

## Future Extensions (post-hackathon)

- Multi-agent swarm (analyst + risk manager + executor)
- Persistent trade journal via local storage or on-chain
- Integration with Binance Skill Hub
- Automated payment workflows (x402)
