# Hackathon Submission Guide

## Track A Requirements

- Build an AI agent with Agent OS
- Submit: video/demo + GitHub (this repo)
- Deadline: Sept 8, 2026 23:59 UTC

## How to Submit

1. **Follow** @Binance on X
2. **Repost** the official hackathon post
3. **Reply or Quote** with:
   - Link to this GitHub repo
   - Short demo video (30–90 seconds recommended)
   - Brief description: "TradePilot AI — full trading workflow agent on Binance Agent OS (Track A)"
4. **Complete the survey**: https://www.binance.com/en/survey/2913aa200aac462c89a737779393f3d4 (or the link in the post)

## Recommended Demo Video Script (60 seconds)

1. Show Claude / ChatGPT with Binance MCP connected
2. Paste the TradePilot system prompt (or say "using TradePilot skill")
3. Ask: "Analyze BTCUSDT with full TradePilot report"
4. Show the structured analysis response
5. Ask for a trade idea with 1% risk
6. Show the complete idea with entry / SL / TP / size
7. End with the GitHub link on screen

## Prize Structure (Track A)

- 1st: 2,000 USDC
- 2nd: 1,500 USDC
- 3rd: 1,000 USDC
- Next 50: 300 USDC each

Good luck!
